package com.greenfoxacademy.springtodos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringtodosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringtodosApplication.class, args);
	}
}
